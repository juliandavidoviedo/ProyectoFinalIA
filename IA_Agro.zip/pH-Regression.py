# -*- coding: utf-8 -*-
"""
Created on Mon May 23 10:46:06 2022

@author: estudiante
"""

import pandas as pd 
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt

#Importación del Dataset 
data = pd.read_csv('NIRSdata.csv',  encoding= 'unicode_escape',sep=',') 
df= pd.DataFrame(data)

# Columnas no necesarias
de= df.drop(df.loc[:,'CODIGO DE LA MUESTRA':'OBSERVACIONES'].columns, axis = 1)
de.head() #Trabajar con este 

# Generación de Dataset Etiqueta pH 
ph=de.loc[:, 'pH'].dropna (axis=0,how='all')
#ph= pd.DataFrame(ph)

# Diccionario para filtrar caracteres especiales
dictionary={'<':'','>':''}
dff=ph.replace(dictionary,regex=True)

ph= pd.DataFrame(dff)
ph.to_csv('ph.csv', encoding= 'utf-8')


# =============================================================================
# phb=de.loc[:, '417':'672'].dropna(axis=0,how='all')
# phb.to_csv('phb.csv', encoding= 'utf-8')
# =============================================================================

# Generación de Dataset Prueba Espectros pH
phb= pd.read_csv('phb.csv',encoding= 'unicode_escape',sep=',')
phb= pd.DataFrame(phb)
buf= phb.loc[:,'451':'604']
phb = pd.DataFrame(buf)

#phb=phb.drop(phb.loc[3709:3985])
print('Estadisticas')
print(ph.describe())
print(phb.describe())


#X_multiple= data.loc[:,'451':'604']
X_multiple=phb
X_multiple.shape

y_multiple=ph
y_multiple.shape

#y_multiple.isnull().sum()

# =============================================================================
# Modelo de regresión lineal múltiple usando Sklearn
# =============================================================================
from sklearn.model_selection import train_test_split
X_train,X_test, y_train, y_test = train_test_split(X_multiple,y_multiple,test_size=0.25)

# Algoritmo-Técnica Regresión Lineal sklearn
from sklearn import linear_model
lr_multiple=linear_model.LinearRegression()

X_train.shape

y_train.shape

#y_multiple.fillna(-99999, inplace=True)

X_train = np.nan_to_num(X_train)
y_train= np.nan_to_num(y_train)

#Entrenamiento de modelo 
lr_multiple.fit(X_train, y_train)

Y_pred_multiple= lr_multiple.predict(X_test)

#dpreditc= pd.DataFrame(Y_pred_multiple)
#Prediction = dpreditc.to_csv('predict.csv', encoding= 'utf-8')
print("Precisión Regresión Lineal PH")
print(lr_multiple.score(X_train, y_train))

print("Coeficientes Regresión Lineal Múltiple")
print (lr_multiple.coef_)


## SVR

########## IMPLEMENTACIÓN DE VECTORES DE SOPORTE REGRESIÓN ##########

from sklearn.model_selection import train_test_split

#Separo los datos de "train" en entrenamiento y prueba para probar los algoritmos
X_train, X_test, y_train, y_test = train_test_split(X_multiple, y_multiple, test_size=0.25)

from sklearn.svm import SVR

#Defino el algoritmo a utilizar
svr = SVR(kernel='rbf',C=1,gamma=0.1, epsilon=0.2, verbose=True)

#Entreno el modelo
svr.fit(X_train, y_train)

#Realizo una predicción
Y_pred = svr.predict(X_test)

#Graficamos los datos junto con el modelo
plt.scatter(Y_pred, Y_pred_multiple)
#plt.scatter(ph, phb)
#plt.scatter(phb, ph)
plt.plot(X_test, Y_pred, color='red', linewidth=3)
plt.show()

print()
print('DATOS DEL MODELO VECTORES DE SOPORTE REGRESIÓN')
print()

print('Precisión del modelo:')
print(svr.score(X_train, y_train))


# """
# Vectores de Soporte Regresión

# @author: ligdigonzalez
# """

# ########## LIBRERÍAS A UTILIZAR ##########

# #Se importan la librerias a utilizar
# import numpy as np
# import matplotlib.pyplot as plt
# from sklearn import datasets


# ########## PREPARAR LA DATA ##########

# #Importamos los datos de la misma librería de scikit-learn
# boston = datasets.load_boston()
# print(boston)
# print()

# ########## ENTENDIMIENTO DE LA DATA ##########

# #Verifico la información contenida en el dataset
# print('Información en el dataset:')
# print(boston.keys())
# print()

# #Verifico las características del dataset
# print('Características del dataset:')
# print(boston.DESCR)

# #Verifico la cantidad de datos que hay en los dataset
# print('Cantidad de datos:')
# print(boston.data.shape)
# print()

# #Verifico la información de las columnas
# print('Nombres columnas:')
# print(boston.feature_names)

# ########## PREPARAR LA DATA VECTORES DE SOPORTE REGRESIÓN ##########

# #Seleccionamos solamente la columna 6 del dataset
# X_svr = boston.data[:, np.newaxis, 5]

# #Defino los datos correspondientes a las etiquetas
# y_svr = boston.target

# #Graficamos los datos correspondientes
# plt.scatter(X_svr, y_svr)
# plt.show()

# ########## IMPLEMENTACIÓN DE VECTORES DE SOPORTE REGRESIÓN ##########

# from sklearn.model_selection import train_test_split

# #Separo los datos de "train" en entrenamiento y prueba para probar los algoritmos
# X_train, X_test, y_train, y_test = train_test_split(X_svr, y_svr, test_size=0.2)

# from sklearn.svm import SVR

# #Defino el algoritmo a utilizar
# svr = SVR(kernel='linear', C=1.0, epsilon=0.2)

# #Entreno el modelo
# svr.fit(X_train, y_train)

# #Realizo una predicción
# Y_pred = svr.predict(X_test)

# #Graficamos los datos junto con el modelo
# plt.scatter(X_test, y_test)
# plt.plot(X_test, Y_pred, color='red', linewidth=3)
# plt.show()

# print()
# print('DATOS DEL MODELO VECTORES DE SOPORTE REGRESIÓN')
# print()

# print('Precisión del modelo:')
# print(svr.score(X_train, y_train))
