# -*- coding: utf-8 -*-
"""
Created on Mon May 23 17:39:16 2022

@author: estudiante
"""

import pandas as pd 
import numpy as np
import scipy as sp
from scipy.signal import savgol_filter

data = pd.read_csv('NIRSdata.csv',  encoding= 'unicode_escape',sep=',') 
#print(data)
#print(data.dtypes)
#print(data.sort_values(by=[Unidad],ascending=[False]))
#y = data['pH'].values.astype(float)
#data = data.drop(columns=['pH'])
#data["Cultivo"].str.split('[.@]', expand=True)
#data["Profundidad"].str.split('[.@]', expand=True)

#data.replace([np.inf, -np.inf], np.nan, inplace=True)
#data.dropna()
#data.reset_index()

# Eliminación de Columnas Inútiles
df= pd.DataFrame(data)
datan=df.dropna(how='all')
datan=pd.DataFrame(datan)
de= df.drop(df.loc[:,'CODIGO DE LA MUESTRA':'OBSERVACIONES'].columns, axis = 1)

de.isnull().sum()

#phdf= de.loc[:,'pH'].columns, axis = 1]
ph=de.loc[:, 'pH'].isnull().sum()

dfph=de.loc[:, 'pH']

#dfph.fillna(dfph.mean, inplace=True)
#print(dfph)

de.loc[:, 'pH'].describe()

#media= de.loc[:, 'pH'].mean()
#print(media)

data.fillna(data.mean, inplace=True)

de.describe()

de.fillna(data.mean, inplace=True)

#**Conjunto de Entrenamiento**
dtr=de.drop(de.loc[:,'400':'2491'].columns, axis = 1)

#**Conjunto de Evaluación**
deval=de.loc[:,'400':'2491']
deval.head()

data.dropna(axis='columns', how='all')

dtr.head()

dtrain=pd.DataFrame(dtr)
dtrain.head()

#dtrainl= dtrain.dropna(axis='columns')
#dtrainl
dtrainl= dtrain.dropna(subset=["Clase textural"])
dtrainl.head()
#print("DataFrame after removing rows with NaN value in any column:")
#print(dtrainl)

dtrainll= dtrain.dropna(subset=["pH"])
dtrainll.head(-1)

dtrainl1= dtrain.dropna(subset=["Boro (B) disponible"])
dtrainl1.head(-1)

training = dtrain.to_csv('train.csv', encoding= 'utf-8')

evaluating = deval.to_csv('eval.csv', encoding= 'utf-8')

dictionary={'<':'','>':''}
dff=dtrain.replace(dictionary,regex=True, inplace=True)
dftrain= pd.DataFrame(dff)
dftrain.head()

print(dtrain)

newposition= dtrain.drop(dtrain.loc[:,'% humedad gravimetrica':'Position'].columns, axis = 1)

newposition.head()

newposition = newposition.to_csv('train_new.csv', encoding= 'utf-8')

#deval[203:]
#Posiciones a filtrar, Valores Nulos
deval.loc[203:245]

deval=deval.dropna(how='all')

deval.head(247)

#deval.loc[203:245]

filtro= deval['400'] != ''
filtrado= deval[filtro]
filtrado.head(245)

# remove rows using the drop() function
devalf=deval.drop(deval.index[deval['400'] == ''], inplace=True)
evaluation= pd.DataFrame(devalf)
evaluation.head()
# display the dataframe

#print(deval.index[deval['400'] == ''])
#deval['400']
# remove rows by filtering
deval = deval[deval['400'] != '']
deval = deval[deval['400'] != 'NaN']
deval.head()
# display the dataframe
#print(devalt[243:400])

df.drop(df.loc[:,'CODIGO DE LA MUESTRA':'OBSERVACIONES'].columns, axis = 1)

evaluat = deval.to_csv('evalu.csv', encoding= 'utf-8')

print (pd.isnull(deval).sum())

print (pd.isnull(dtrain).sum())

print (deval.shape)
print (dtrain.shape)

print('Estadisticas')
print(dtrain.describe())

print(deval.describe())

dtrain.head()



dtrain['pH'].describe()

df.shape

dtrain.shape

deval.shape

deval.head()

X_multiple= data.loc[:,'451':'604']

X_multiple.shape

y_multiple=dtrain.loc[:,'pH']

y_multiple.shape

y_multiple.isnull().sum()

from sklearn.model_selection import train_test_split
X_train,X_test, y_train, y_test = train_test_split(X_multiple,y_multiple,test_size=0.25)

X_multiple.isnull().sum()

# Algoritmo-Técnica Regresión Lineal 
from sklearn import linear_model
lr_multiple=linear_model.LinearRegression()

X_train.shape

y_train.shape

#y_multiple.fillna(-99999, inplace=True)

X_train = np.nan_to_num(X_train)
y_train= np.nan_to_num(y_train)

#Entrenamiento de modelo 
lr_multiple.fit(X_train, y_train)

Y_pred_multiple= lr_multiple.predict(X_test)

dpreditc= pd.DataFrame(Y_pred_multiple)
Prediction = dpreditc.to_csv('predict.csv', encoding= 'utf-8')

print(lr_multiple.score(X_train, y_train))

print (Y_pred_multiple)

print (lr_multiple.coef_)
