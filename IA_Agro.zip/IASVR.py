
# -*- coding: utf-8 -*-
"""
Proyecto IA
Estimación mediante la Predicción de:
    ph Intercambiable usando ML 
Creado un Mayo de 2022 PUJ
Presentado a Francisco Calderón phD
@authores: Julián Oviedo
        Andrés Camilo Ángel
"""

#Importación de librerías

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns; 
import sklearn

#Importación del Dataset 
data = pd.read_csv('NIRSdata.csv',  encoding= 'unicode_escape',sep=',') 
df= pd.DataFrame(data)

# Columnas no necesarias
de= df.drop(df.loc[:,'CODIGO DE LA MUESTRA':'OBSERVACIONES'].columns, axis = 1)
de.head() #Trabajar con este 

#Reemplazo de Caracteres especiales
dictionary={'<':'','>':''}
df=de.replace(dictionary,regex=True)
dat= pd.DataFrame(df) # Dataset sin carcateres especiales

#Rango abosrbancia pH
dataset=dat.loc[:, 'pH':'689']
dataset.dropna(axis=0,how='all', inplace=True)
datos= dataset.drop(dataset.loc[:,'Materia orgánica (MO)':'Sample Identification String One'].columns, axis = 1)
datos.head() # Dataset con NA aún

# Limpieza de NAN
dats=datos.dropna() 
dats.isnull().sum()
dats.describe() # Estadisticas 
dats.head()
dats.to_csv('datsph.csv', encoding= 'utf-8') # Archivo CSV pH

# Generación de Dataset Etiqueta pH 
ph=de.loc[:, 'pH'].dropna (axis=0,how='all')  # Etiqueta sin NAN 

# Diccionario para filtrar caracteres especiales en Conjunto de Etiqueta pH
dictionary={'<':'','>':''}
dff=ph.replace(dictionary,regex=True)

ph= pd.DataFrame(dff) # Conversión a dataframe de pH por filtrado de caracteres
ph.to_csv('ph.csv', encoding= 'utf-8')

# Filtrado de Caracteres para dataset-Bandas
df=de.replace(dictionary,regex=True)
Dat= pd.DataFrame(df) 

de= df.drop(df.loc[:,'Materia orgánica (MO)':'Sample Identification String One'].columns, axis = 1)
de.to_csv('dat.csv', encoding= 'utf-8')

# =============================================================================
dataset=de.loc[:, 'pH':'689'].dropna(axis=0,how='all')
de.to_csv('phbands.csv', encoding= 'utf-8')
# =============================================================================

# Generación de Dataset Prueba Espectros pH (Igual tamaño para pH)
phb= pd.read_csv('phb.csv',encoding= 'unicode_escape',sep=',') #predictores
phb= pd.DataFrame(phb)
buf= phb.loc[:,'451':'604']
phb = pd.DataFrame(buf)

#Estadisticas Dataset
print('Estadisticas')
print(ph.describe())
print(phb.describe())

X_multiple=phb
X_multiple.shape

y_multiple=ph
y_multiple.shape

#####################################################################
#                              SVR

########## IMPLEMENTACIÓN DE VECTORES DE SOPORTE REGRESIÓN ##########

from sklearn.model_selection import train_test_split

#Separo los datos de "train" en entrenamiento y prueba para probar los algoritmos
X_train, X_test, y_train, y_test = train_test_split(X_multiple, y_multiple, test_size=0.25)

from sklearn.svm import SVR

#Defino el algoritmo a utilizar
svr = SVR(kernel='rbf',C=1000,gamma=1, epsilon=0.5, verbose=True)

#Entreno el modelo
svr.fit(X_train, y_train)

#Realizo una predicción
Y_pred = svr.predict(X_test)


#Graficamos los datos junto con el modelo
#plt.scatter(Y_pred, Y_pred_multiple)
#plt.scatter(ph, phb)
#plt.scatter(phb, ph)
plt.plot(y_test, Y_pred,'b.',label="pH")
plt.title('Regresión mediante Soporte Vectorial')
plt.xlabel('pH_Validación')
plt.ylabel('pH Predicho')
plt.show()

plt.plot(y_test,'r.')
plt.xlabel('Index')
plt.ylabel('pH Validación')
plt.show()

plt.plot (Y_pred,'b.')
plt.xlabel('Index')
plt.ylabel('pH Predicho')
plt.show()



print()
print('DATOS DEL MODELO VECTORES DE SOPORTE REGRESIÓN')
print()

print('Precisión del modelo:')
print(svr.score(X_train, y_train))
# =============================================================================
#           Optimización de Hiperparámetros SVR
# =============================================================================

from sklearn.model_selection import GridSearchCV
#from sklearn.svm import SVR
grid = GridSearchCV(estimator=SVR(kernel='rbf'),
        param_grid={
            'C': [0.1, 1, 100, 1000],
            'epsilon': [0.0001, 0.0005, 0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 5, 10],
            'gamma': [0.0001, 0.001, 0.005, 0.1, 1, 3, 5]
        },
        cv=5, scoring='neg_mean_squared_error', verbose=0, n_jobs=-1)

## Con R2

# 0.022035280409098034
# SVR(C=100, epsilon=0.5, gamma=1)

## Con neg_mean_squared_error




clf= grid.fit(X_train, y_train)
#print the best score throughout the grid search
bests=clf.best_score_
print(np.abs(np.mean(bests)))
#print the best parameter used for the highest score of the model.
beste=clf.best_estimator_ 
print (beste)