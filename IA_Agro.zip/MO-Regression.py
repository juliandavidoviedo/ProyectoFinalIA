# -*- coding: utf-8 -*-
"""
Created on Mon May 23 16:59:26 2022

@author: estudiante
"""

import pandas as pd 
import numpy as np
import scipy as sp

# Importación del Dataset 
data = pd.read_csv('NIRSdata.csv',  encoding= 'unicode_escape',sep=',') 
df= pd.DataFrame(data)

# Columnas no necesarias
de= df.drop(df.loc[:,'CODIGO DE LA MUESTRA':'OBSERVACIONES'].columns, axis = 1)
de.head() #Trabajar con este 

# Generación de Dataset Etiqueta Materia Organica MO
MO=de.loc[:, 'Materia orgánica (MO)'].dropna (axis=0,how='all')
MO= pd.DataFrame(MO)

# Diccionario para filtrar caracteres especiales
dictionary={'<':'','>':''}
dff=MO.replace(dictionary,regex=True)

MO= pd.DataFrame(dff)
MO.to_csv('MO.csv', encoding= 'utf-8')


# =============================================================================
#MOB=de.loc[:, '417':'672'].dropna(axis=0,how='all')
#MOB.to_csv('MOB.csv', encoding= 'utf-8')
# =============================================================================

# Generación de Dataset Prueba Espectros pH
MOB= pd.read_csv('MOB.csv',encoding= 'unicode_escape',sep=',')
MOB= pd.DataFrame(MOB)
#buf= phb.loc[:,'417':'672']
#phb = pd.DataFrame(buf)

#phb=phb.drop(phb.loc[3709:3985])
print('Estadisticas')
print(MO.describe())
print(MOB.describe())


#X_multiple= data.loc[:,'451':'604']
X_multiple=MOB
X_multiple.shape

y_multiple=MO
y_multiple.shape

#y_multiple.isnull().sum()

# =============================================================================
# Modelo de regresión lineal múltiple usando Sklearn
# =============================================================================
from sklearn.model_selection import train_test_split
X_train,X_test, y_train, y_test = train_test_split(X_multiple,y_multiple,test_size=0.25)

# Algoritmo-Técnica Regresión Lineal sklearn
from sklearn import linear_model
lr_multiple=linear_model.LinearRegression()

X_train.shape

y_train.shape

#y_multiple.fillna(-99999, inplace=True)

#X_train = np.nan_to_num(X_train)
#y_train= np.nan_to_num(y_train)

#Entrenamiento de modelo 
lr_multiple.fit(X_train, y_train)

Y_pred_multiple= lr_multiple.predict(X_test)

#dpreditc= pd.DataFrame(Y_pred_multiple)
#Prediction = dpreditc.to_csv('predict.csv', encoding= 'utf-8')

print(lr_multiple.score(X_train, y_train))

print (lr_multiple.coef_)



