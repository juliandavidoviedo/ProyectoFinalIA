# -*- coding: utf-8 -*-
"""
Proyecto IA
Estimación mediante la Predicción de:
    ph usando ML 
Creado un Mayo de 2022 PUJ
Presentado a Francisco Calderón phD
@authores: Julián Oviedo
        Andrés Camilo Ángel
"""

#Importación de librerías

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns; 
import sklearn

#Importación del Dataset 
data = pd.read_csv('NIRSdata.csv',  encoding= 'unicode_escape',sep=',') 
df= pd.DataFrame(data)

# Columnas no necesarias
de= df.drop(df.loc[:,'CODIGO DE LA MUESTRA':'OBSERVACIONES'].columns, axis = 1)
de.head() #Trabajar con este 

#Reemplazo de Caracteres especiales
dictionary={'<':'','>':''}
df=de.replace(dictionary,regex=True)
dat= pd.DataFrame(df) # Dataset sin carcateres especiales

#Rango abosrbancia pH
dataset=dat.loc[:, 'pH':'689']
dataset.dropna(axis=0,how='all', inplace=True)
datos= dataset.drop(dataset.loc[:,'Materia orgánica (MO)':'Sample Identification String One'].columns, axis = 1)
datos.head() # Dataset con NA aún

# Limpieza de NAN
dats=datos.dropna() 
dats.isnull().sum()
dats.describe() # Estadisticas 
dats.head()
dats.to_csv('datsph.csv', encoding= 'utf-8') # Archivo CSV pH

# Generación de Dataset Etiqueta pH 
ph=de.loc[:, 'pH'].dropna (axis=0,how='all')  # Etiqueta sin NAN 

# Diccionario para filtrar caracteres especiales en Conjunto de Etiqueta pH
dictionary={'<':'','>':''}
dff=ph.replace(dictionary,regex=True)

ph= pd.DataFrame(dff) # Conversión a dataframe de pH por filtrado de caracteres
ph.to_csv('ph.csv', encoding= 'utf-8')

# Filtrado de Caracteres para dataset-Bandas
df=de.replace(dictionary,regex=True)
Dat= pd.DataFrame(df) 

de= df.drop(df.loc[:,'Materia orgánica (MO)':'Sample Identification String One'].columns, axis = 1)
de.to_csv('dat.csv', encoding= 'utf-8')

# =============================================================================
dataset=de.loc[:, 'pH':'689'].dropna(axis=0,how='all')
de.to_csv('phbands.csv', encoding= 'utf-8')
# =============================================================================

# Generación de Dataset Prueba Espectros pH (Igual tamaño para pH)
phb= pd.read_csv('phb.csv',encoding= 'unicode_escape',sep=',') #predictores
phb= pd.DataFrame(phb)
buf= phb.loc[:,'451':'604']
phb = pd.DataFrame(buf)

#Estadisticas Dataset
print('Estadisticas')
print(ph.describe())
print(phb.describe())

X_multiple=phb
X_multiple.shape

y_multiple=ph
y_multiple.shape



print (" Estimación de pH con Regresión Lineal Múltiple")
from sklearn.model_selection import train_test_split
X_train,X_test, y_train, y_test = train_test_split(X_multiple,y_multiple,test_size=0.25)


# =============================================================================
#                   Modelo de Red Neuronal Artificial para Regresión
# =============================================================================
from sklearn.neural_network import MLPRegressor
from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split


regr = MLPRegressor(hidden_layer_sizes=(10,10,10), activation='relu',random_state=42, max_iter=1000).fit(X_train, y_train)

Ann_reg= regr.predict(X_test)

print("Métricas MLP Score")
print (regr.score(X_train, y_train))
print("Métrica MLP Score R2 Test")
print(regr.score(X_test, y_test))


# =============================================================================
#                       Regularización L2
# =============================================================================
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score

modelRidge= Ridge(alpha=0).fit(X_train, y_train)
y_predict_ridge= modelRidge.predict(X_test)

dpreditc= pd.DataFrame(Ann_reg)
Prediction = dpreditc.to_csv('predictANN.csv', encoding= 'utf-8')

print( "Aquí las metricas de pérdida...")

ANN_loss= mean_squared_error(y_test, Ann_reg)
print (" R2 Test ")
print(ANN_loss)

ANN_ridge_loss= mean_squared_error(y_test, y_predict_ridge)
print ("R2 Test con Regularización")
print(ANN_ridge_loss)

# =============================================================================
#  Gráficas informativas modelo 
# =============================================================================

yytest= y_test.to_numpy()

plt.plot(yytest, Ann_reg,'b.',label="pH")
plt.title('Regresión usando Perceptrón Multicapa')
plt.xlabel('pH_Validación')
plt.ylabel('pH Predicho')
plt.show()

plt.plot(y_test,'r.')
plt.title('MLP Test ')
plt.xlabel('Index')
plt.ylabel('pH Validación')
plt.show()

plt.plot (Ann_reg,'b.')
plt.title('MLP Predicción pH')
plt.xlabel('Index')
plt.ylabel('pH Predicho')
plt.show()
