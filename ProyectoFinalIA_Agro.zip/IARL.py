# -*- coding: utf-8 -*-
"""
Proyecto IA
Estimación mediante la Predicción de:
    ph usando ML 
Creado un Mayo de 2022 PUJ
Presentado a Francisco Calderón Ph.D
@authores: Julián Oviedo
        Andrés Camilo Ángel
"""

#Importación de librerías

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns; 
import sklearn

#Importación del Dataset 
data = pd.read_csv('NIRSdata.csv',  encoding= 'unicode_escape',sep=',') 
df= pd.DataFrame(data)

# Columnas no necesarias
de= df.drop(df.loc[:,'CODIGO DE LA MUESTRA':'OBSERVACIONES'].columns, axis = 1)
de.head() #Trabajar con este 

#Reemplazo de Caracteres especiales
dictionary={'<':'','>':''}
df=de.replace(dictionary,regex=True)
dat= pd.DataFrame(df) # Dataset sin carcateres especiales

#Rango abosrbancia pH
dataset=dat.loc[:, 'pH':'689']
dataset.dropna(axis=0,how='all', inplace=True)
datos= dataset.drop(dataset.loc[:,'Materia orgánica (MO)':'Sample Identification String One'].columns, axis = 1)
datos.head() # Dataset con NA aún

# Limpieza de NAN
dats=datos.dropna() 
dats.isnull().sum()
dats.describe() # Estadisticas 
dats.head()
dats.to_csv('datsph.csv', encoding= 'utf-8') # Archivo CSV pH

# Generación de Dataset Etiqueta pH 
ph=de.loc[:, 'pH'].dropna (axis=0,how='all')  # Etiqueta sin NAN 

# Diccionario para filtrar caracteres especiales en Conjunto de Etiqueta pH
dictionary={'<':'','>':''}
dff=ph.replace(dictionary,regex=True)

ph= pd.DataFrame(dff) # Conversión a dataframe de pH por filtrado de caracteres
ph.to_csv('ph.csv', encoding= 'utf-8')

# Filtrado de Caracteres para dataset-Bandas
df=de.replace(dictionary,regex=True)
Dat= pd.DataFrame(df) 

de= df.drop(df.loc[:,'Materia orgánica (MO)':'Sample Identification String One'].columns, axis = 1)
de.to_csv('dat.csv', encoding= 'utf-8')

# =============================================================================
dataset=de.loc[:, 'pH':'689'].dropna(axis=0,how='all')
de.to_csv('phbands.csv', encoding= 'utf-8')
# =============================================================================

# Generación de Dataset Prueba Espectros pH (Igual tamaño para pH)
phb= pd.read_csv('phb.csv',encoding= 'unicode_escape',sep=',') #predictores
phb= pd.DataFrame(phb)
buf= phb.loc[:,'451':'604']
phb = pd.DataFrame(buf)

#Estadisticas Dataset
print('Estadisticas')
print(ph.describe())
print(phb.describe())

X_multiple=phb
X_multiple.shape

y_multiple=ph
y_multiple.shape


# =============================================================================
#             Modelo de regresión lineal múltiple usando Sklearn
# =============================================================================

print (" Estimación de pH con Regresión Lineal Múltiple")
from sklearn.model_selection import train_test_split
X_train,X_test, y_train, y_test = train_test_split(X_multiple,y_multiple,test_size=0.25)

# Algoritmo-Técnica Regresión Lineal sklearn
from sklearn import linear_model
lr_multiple=linear_model.LinearRegression()

X_train.shape
y_train.shape

# =============================================================================
#                            Cross_Validation
# =============================================================================
from sklearn.model_selection import (cross_val_score,KFold)
score= cross_val_score(lr_multiple,X_multiple,y_multiple, scoring='neg_mean_squared_error')
score2= cross_val_score(lr_multiple,X_multiple,y_multiple, scoring='r2')
print("cross_val neg")
print(np.abs(np.mean(score)))
print("cross_val r2")
print(np.abs(np.mean(score2)))

# =============================================================================
#                       Regularización L2
# =============================================================================
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error

modelRidge= Ridge(alpha=0).fit(X_train, y_train)
y_predict_ridge= modelRidge.predict(X_test)

from time import time
 # Start counting.
start_time = time()
       
       #Entrenamiento de modelo regresion lineal múltiple
print( "Entrenando...")
lr_multiple.fit(X_train, y_train)
# Calculate the elapsed time.
elapsed_time = time() - start_time
print( "Entrenado...")
 
print("Elapsed time: %0.10f seconds." % elapsed_time)
    
    
print( "Ahora a probar el modelo de regresión :D...")

Y_pred_multiple= lr_multiple.predict(X_test)
Y_pred_lineal = pd.DataFrame(Y_pred_multiple)

print( "Aquí las metricas de pérdida...")

linear_loss= mean_squared_error(y_test, Y_pred_multiple)
print (" R2 Test ")
print(linear_loss)

ridge_loss= mean_squared_error(y_test, y_predict_ridge)
print ("R2 Test con Regularización")
print(ridge_loss)

#dpreditc= pd.DataFrame(Y_pred_multiple)
#Prediction = dpreditc.to_csv('predict.csv', encoding= 'utf-8')
print("Precisión Regresión Lineal PH")
print ("")
print ("Para conjunto de entrenamiento R2")
print(lr_multiple.score(X_train, y_train))
print ("Para conjunto de Validación R2")
print (lr_multiple.score(X_test, y_test))

# print("Coeficientes Regresión Lineal Múltiple")
# print (lr_multiple.coef_)

plt.plot(y_test, Y_pred_multiple,'b.',label="pH")
plt.title('Regresión Lineal Múltiple')
plt.xlabel('pH_Validación')
plt.ylabel('pH Predicho')
plt.show()

plt.plot(y_test,'r.')
plt.title('Regresión Lineal Múltiple Test')
plt.xlabel('Index')
plt.ylabel('pH Validación')
plt.show()

plt.plot (Y_pred_multiple,'b.')
plt.title('Regresión Lineal Múltiple Predicción')
plt.xlabel('Index')
plt.ylabel('pH Predicho')
plt.show()
